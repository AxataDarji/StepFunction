import json
import hashlib
import urllib.request
import urllib.parse
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # Use logging.DEBUG for more verbose logging

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))
    
    # Get the endpoint URL from the input JSON
    course_uri = event.get('course_uri')
    if not course_uri:
        logger.error("Error: course_uri not found in the incoming event.")
        return {
            'statusCode': 400,
            'body': json.dumps('Error: course_uri not found in the incoming event.')
        }
    
    logger.info("Course URI: %s", course_uri)

    # Get the string to encrypt from the event
    input_string = event.get('value')
    if not input_string:
        logger.error("Error: value not found in the event received.")
        return {
            'statusCode': 400,
            'body': json.dumps('Error: value not found in the event received.')
        }
    
    logger.info("Input string to encrypt: %s", input_string)

    try:
        # Encrypting the string using MD5
        input_bytes = input_string.encode('utf-8')
        encrypted_bytes = hashlib.md5(input_bytes).digest()
        encrypted_string = encrypted_bytes.hex()  # Converting the encrypted bytes to hexadecimal string
        
        logger.info("MD5 Encryption successful. Encrypted string: %s", encrypted_string)
    except Exception as e:
        logger.error("Error during MD5 encryption: %s", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error during MD5 encryption: {str(e)}')
        }
    
    # Prepare the response JSON
    response = {
        "banner": "B00985046",
        "result": encrypted_string,
        "arn": "arn:aws:lambda:us-east-1:698915160078:function:md5-lambda-function",
        "action": "md5",
        "value": input_string
    }
    
    logger.info("Prepared response: %s", json.dumps(response))

    # Convert the response JSON to string
    response_body = json.dumps(response)
    
    # Post the response to the endpoint serverless/end
    headers = {'Content-Type': 'application/json'}
    request = urllib.request.Request(course_uri, data=response_body.encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(request) as response:
            if response.status == 200:
                logger.info("Successfully posted response to endpoint. Status code: %d", response.status)
                return {
                    'statusCode': 200,
                    'body': json.dumps('Success')
                }
            else:
                logger.error("Error posting response to the endpoint. Status code: %d", response.status)
                return {
                    'statusCode': response.status,
                    'body': json.dumps('Error posting response to the endpoint.')
                }
    except Exception as e:
        logger.error("Exception occurred while posting response: %s", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
